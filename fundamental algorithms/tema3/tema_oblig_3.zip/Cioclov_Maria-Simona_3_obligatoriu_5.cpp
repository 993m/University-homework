// O(n*n*2^n)
// Return the length of the shortest path that visits every node. 
// You may start and stop at any node, you may revisit nodes multiple times, and you may reuse edges.

class Solution {
public:
    int shortestPathLength(vector<vector<int>>& graph) {
        int n = graph.size();
        int finalState = (1 << n) - 1;
		
		// in viz[][] tin minte si daca o stare se repeta pentru un nod, 
		// dar si nivelul acelui nod ({nod, stare}) in bfs
        int viz[n][finalState+1]; 
        for(int i=0; i<n; i++)
            for(int j=0; j<=finalState; j++) viz[i][j] = 0;
		
        queue<pair<int, int>> bfs; // {nod, stare}
		
		// pun la inceput in coada toate nodurile
		
        for(int i=0; i<n; i++) bfs.push({i, 1 << i}), viz[i][1 << i] = 1;

        int k = 0; 
        while(!bfs.empty()){
            auto x = bfs.front();
            bfs.pop();
            for(auto y: graph[x.first]){
                int newState = x.second | (1 << y);
                if(newState == finalState) return viz[x.first][x.second];
                if(!viz[y][newState]){
                    viz[y][newState] = viz[x.first][x.second] + 1;
                    bfs.push({y, newState});
                }
            }     
        }
        return 0;
    }
};