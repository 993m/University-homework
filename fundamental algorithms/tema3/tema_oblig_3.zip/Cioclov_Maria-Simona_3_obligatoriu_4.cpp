// O(n+m)

class Solution {
public:
    vector<vector<int>> v;
    map<int, vector<int>> m; // lista de adiacenta
    map<int, pair<int, int>> g; // in, out

    void dfs(int x){
        while(!m[x].empty()){
            int y = m[x].back();
            m[x].pop_back();
            dfs(y);
            v.push_back({x, y});
        }
    }
            

    vector<vector<int>> validArrangement(vector<vector<int>>& pairs) {        
        for(auto p: pairs){
            int x, y;
            x = p[0];
            y = p[1];
            if(m.count(x)){
                g[x].second ++;
                m[x].push_back(y);
            }
            else m[x] = {y}, g[x] = {0, 1};

            if(m.count(y)) g[y].first ++;
            else g[y] = {1, 0}, m[y] = {}; 
        }


		// gasesc un elemtn care are gradIesire - gradIntrare = 1,
		// apoi incep dfs de la acel nod
		
        int x = -1;
        for(auto elem: g){
            auto key = elem.first;
            auto grade = elem.second;
            if(grade.second - grade.first == 1) {
                x = key;
                break;
            }
        }

        if(x == -1) x = pairs[0][0];
        dfs(x);
        reverse(v.begin(), v.end());
        return v;

    }
};