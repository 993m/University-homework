// Edmonds-Karp, O(m^2 * n)

#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

vector<vector<vector<int>>> lista; // {nod, capacitate, indexMuchieInversa}


int main(){
    int n, m, e, x, y, t;
    fin>>n>>m>>e;
    t = n+m+2;
    lista.resize(t);

	for(int i=1; i<=e; i++){
        fin>>x>>y;
        y = n + y;
        int ySize = lista[y].size();
        int xSize = lista[x].size();
        lista[x].push_back({y, 1, ySize});
        lista[y].push_back({x, 0, xSize});
    }

	// adaug nod sursa
    for(int i=1; i<=n; i++){
        int zSize = lista[0].size();
        int iSize = lista[i].size();
        lista[0].push_back({i, 1, iSize});
        lista[i].push_back({0, 0, zSize});
    }

	//adaug nod destinatie
    for(int i=n+1; i<=t-2; i++){
        int tSize = lista[t-1].size();
        int iSize = lista[i].size();
        lista[t-1].push_back({i, 0, iSize});
        lista[i].push_back({t-1, 1, tSize});
    }


    int F=0;
	// cat timp gasesc cate un drum de ameliorare
    while(true){
        vector<vector<int>> parent (t, {-2, 0});
        queue<int> bfs;
        bfs.push(0);
        parent[0] = {-1, 0};

		// obtin cu bfs cel mai scurt drum de la sursa la destinatie
        while(!bfs.empty()){
            x = bfs.front();
            bfs.pop();

            for(int i=0; i<lista[x].size(); i++) {
                auto v = lista[x][i];
                y = v[0];
                if (parent[y][0] == -2 && v[1]) {
                    parent[y] = {x, i};
                    if (y == t - 1) break;
                    bfs.push(y);
                }
            }

            if(parent[t-1][0] != -2) break;
        }

		// daca am gasit un drum
        if(parent[t-1][0] != -2) {
            int p = parent[t-1][0];
            int x = t-1;
            int index = parent[x][1];
            F++;
			// actualizez capacitatea muchiilor de pe acel drum
            while (p != -1){
                lista[p][index][1] -= 1;
                lista[x][lista[p][index][2]][1] += 1;
                x = p;
                p = parent[x][0];
                index = parent[x][1];
            }

        }

        else break;
    }

    fout<<F<<'\n';
    for(int i=1; i<=n; i++)
        for(int j=0; j<lista[i].size()-1; j++)
            if(!lista[i][j][1]) fout<<i<<" "<<lista[i][j][0]-n<<'\n';
}