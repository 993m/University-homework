// Edmonds-Karp, O(m^2 * n)

#pragma GCC optimize "O3"
#include <bits/stdc++.h>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

queue<int> bfs;
vector<int> parent;
vector<vector<int>> lista, cap;

int main(){
    int n, m, x, y, z;
    fin>>n>>m;
    lista.resize(n+1);
    cap.resize(n+1);
    for(int i=1;i<=n;i++) cap[i].resize(n+1);

    for(int i=1; i<=m; i++){
        fin>>x>>y>>z;
        lista[x].push_back(y);
        lista[y].push_back(x);
        cap[x][y] = z;
    }

    parent.resize(n+1);
    int b, p, F=0;

    // cat timp gasesc cate un drum de ameliorare
    while(true){
        bfs.push(1);
        parent[1] = -1;

        // obtin cu bfs cel mai scurt drum de la sursa la destinatie
        while(!bfs.empty()){
            x = bfs.front();
            bfs.pop();

            for(auto y: lista[x])
                if(parent[y] == 0  && cap[x][y]) {
                    parent[y] = x;
                    if(y == n) break;
                    bfs.push(y);

                }

            if(parent[n]) break;
        }

        p = parent[n];
        // daca am gasit un drum
        if(p != 0) {
            // aflu fluxul maxim pe care il pot adauga pe acel drum (capacitatea minima)
            b = 111000;
            x = n;
            while (p != -1) {
                if(cap[p][x] < b) b = cap[p][x];
                x = p;
                p = parent[p];
            }

            // adaug valoarea gasita la fluxul maxim total
            F += b;

            // actualizez capacitatea muchiilor de pe acel drum
            x = n;
            p = parent[x];
            while (p != -1){
                cap[p][x] -= b;
                cap[x][p] += b;
                x = p;
                p = parent[p];
            }

            fill(parent.begin(), parent.end(), 0);
            while(!bfs.empty()) bfs.pop();
        }

        else break;
    }

    fout<<F;
}