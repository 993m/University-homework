class Solution {
public: 

	// a) programare dinamica, O(n*m)
	
    int longestCommonSubsequence(string text1, string text2) {
        int m[1001][1001]; 
        for(int i=0; text1[i]; i++)
            for(int j=0; text2[j]; j++)
                if(text1[i] == text2[j]) m[i+1][j+1] = m[i][j] + 1;
                else m[i+1][j+1] = max(m[i][j+1], m[i+1][j]);

        return m[text1.length()][text2.length()];
    }
	
	
	
	// b) programare dinamica, O(n*m)
	// fac intai problema longestCommonSubsequence si obtin matricea cu drumul pentru cel mai lung subsir comun,
	// apoi creez oglinditul cuvantul cerut parcurgand drumul din matrice de la coada la inceput 
	string shortestCommonSupersequence(string str1, string str2) {
        int m[1001][1001]; 
        for(int i=0; str1[i]; i++)
            for(int j=0; str2[j]; j++)
                if(str1[i] == str2[j]) m[i+1][j+1] = m[i][j] + 1;
                else m[i+1][j+1] = max(m[i][j+1], m[i+1][j]);

        string s = "";

        int i = str1.length(), j = str2.length();
        while (i >= 1 && j >= 1)
            if(m[i][j] == m[i-1][j]) s += str1[i-1], i--;
                else if(m[i][j] == m[i][j-1]) s += str2[j-1], j--;
                else s += str1[i-1], i--, j--;

        while(i>=1) s += str1[i-1], i--;
        while(j>=1) s += str2[j-1], j--;

        reverse(s.begin(), s.end());
        return s;
    }
};