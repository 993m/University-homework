/*
 * Prim, O(n*n)
 */

#include <bits/stdc++.h>
class Solution {
public:
    int manhattan(vector<int> &x, vector<int> &y){
        return abs(x[0] - y[0]) + abs(x[1] - y[1]);
    }

    int minCostConnectPoints(vector<vector<int>>& points) {
        int ct = 0, minim, n = points.size(), nod;
        vector<bool> viz (n); // daca un nod a fost vizitat
        vector<int> dist (n, 1e9); // distantele minime pana la noduri
        dist[0] = 0;

        for(int i=0; i<n; i++){
            minim = 1e9;
            // aleg nodul nevizitat pana la care am distanta minima
            for(int j=0; j<n; j++)
                if(!viz[j] && dist[j] < minim) minim = dist[j], nod = j;
            ct += minim;
            viz[nod] = 1; // il marchez vizitat
            // actualizez distantele minime folosindu ma de acel nod
            for(int j=0; j<n; j++)
                if(!viz[j] && manhattan(points[nod], points[j]) < dist[j])
                    dist[j] = manhattan(points[nod], points[j]);
        }

        return ct;
    }
};