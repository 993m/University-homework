/*
 * Sortez si muchiile si query-urile dupa costuri respectiv limite.
 * Pentru fiecare query:
 *        - parcurg muchiile cu cost mai mic decat limita query-ului,
 *          unind multimile din care fac parte capetele unei muchii
 *          
 *        - intre doua noduri exista un drum daca acestea se gasesc in aceeasi multime
 *        
 * O(eloge + vlogv) (sortarile)
 */

#include <bits/stdc++.h>

class DSU {
public:
    vector<int> parent;
    vector<int> height;

    DSU(int n) {
        parent.resize(n, -1);
        height.resize(n);
    }

    int root(int x){
        if(parent[x] == -1) return x;
        return root(parent[x]);
    }

    void dsu_union(int x, int y){
        int rx = root(x), ry = root(y);
        if(rx != ry)
            if(height[rx] > height[ry]) parent[ry] = rx;
            else if(height[rx] == height[ry]) parent[ry] = rx, height[rx]++;
            else parent[rx] = ry;
    }
};

class Solution {
public:
    static bool comp(vector<int>&x, vector<int>&y){
        return (x[2] < y[2]);
    }

    vector<bool> distanceLimitedPathsExist(int n, vector<vector<int>>& edgeList, vector<vector<int>>& queries) {

        DSU dsu(n);
        vector<bool> v(queries.size());
        for(int i=0; i<queries.size(); i++) queries[i].push_back(i);

        sort(edgeList.begin(), edgeList.end(), comp);
        sort(queries.begin(), queries.end(), comp);

        int i = 0;
        for(auto q: queries){

            for(i; i < edgeList.size() && edgeList[i][2] < q[2]; i++)
                dsu.dsu_union(edgeList[i][0], edgeList[i][1]);

            if(dsu.root(q[0]) == dsu.root(q[1])) v[q[3]]=1;
        }

        return v;
    }
};

