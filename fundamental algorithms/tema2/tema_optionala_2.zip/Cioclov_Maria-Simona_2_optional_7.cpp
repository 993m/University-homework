/*
* Bellman-Ford, O(k*e)
*/

#include <bits/stdc++.h>

class Solution {
public:
    int findCheapestPrice(int n, vector<vector<int>>& flights, int src, int dst, int k) {
        vector<int> v(n, 1e9);
        vector<int> c;
        v[src] = 0;
        c = v;
        for(int i=0; i<=k; i++){

	    // la pasul i o sa am in v costurile minime pentru drumurile de lungime maxim i

            for(auto e: flights){
                c[e[1]] = min(c[e[1]], v[e[0]] + e[2]);
            }  
            v = c;
        }

        if(v[dst] == 1e9) return -1;
        return v[dst];
    }
};