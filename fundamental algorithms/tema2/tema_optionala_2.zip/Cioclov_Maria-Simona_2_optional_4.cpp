/*
 * O(mlogn) + O(q * nlogn)
 */

#include <bits/stdc++.h>

using namespace std;
ifstream fin("apm2.in");
ofstream fout("apm2.out");
int parent[10001], h[10001];

struct Edge {
    int x, y, c;
} e[100000];

vector<Edge> v;

bool comp(Edge e1, Edge e2){
    return (e1.c < e2.c);
}

void init(){
    for(int i=1; i<=10000; i++)
        parent[i] = h[i] = 0;
}

int Root(int x){
    if(parent[x] == 0) return x;
    return Root(parent[x]);
}

bool Union(int x, int y){
    int r1 = Root(x);
    int r2 = Root(y);
    if(r1 != r2) {
        if(h[r1] < h[r2]) parent[r1] = r2;
        else if(h[r1] == h[r2]) parent[r1] = r2, h[r2] += 1;
        else parent[r2] = r1;

        return 1;
    }

    return 0;
}

int main() {
    int n, m, sel = 0, q, x, y, ct = 0, c;
    fin >> n >> m >> q;
    for (int i=0; i<m; i++) {
        fin >> e[i].x >> e[i].y >> e[i].c;
    }

    sort(e, e+m, comp);

    // aflu apm-ul initial
    for(int i=0; i<m and sel<n-1; i++)
        if(Union(e[i].x, e[i].y)){
            sel++;
            v.push_back(e[i]);
            ct += e[i].c;
        }

    for(int i=0; i<q; i++){
        fin >> x >> y;
        
        // aflu costul apm-ului care contine de la inceput muchia (x, y, 0)
        
        c = 0;
        init();
        Union(x, y);
        sel = 1;
        
        for(int i=0; i<n-1 and sel<n-1; i++)
            if(Union(v[i].x, v[i].y)){
                sel++;
                c += v[i].c;
            }

        // costul apm-ului initial - constul noului apm - 1 
        // (costul celei mai mari muchii lipsa - 1)
        fout << ct - c - 1 << '\n';
    }
}