/*
 * Fac un kruskal initial, dupa care, daca noua muchie citita e mia mica decat cea mai mare muchie din vechiuil apm,
 * fac iar kruskal (pe vector de doar n elemente de data asta).
 *
 * O(mlogm) + O(k*nlogn) 
 */

#include <bits/stdc++.h>
using namespace std;
ifstream fin("online.in");
ofstream fout("online.out");
int n, parent[201], height[201];
vector<vector<int>> muchii, v;

int Root(int x){
    if(parent[x] == -1) return x;
    return Root(parent[x]);
}

bool Union(int x, int y){
    int r1 = Root(x), r2 = Root(y);
    if(r1 != r2){
        if(height[r1] > height[r2]) parent[r2] = r1;
        else if(height[r1] < height[r2]) parent[r1] = r2;
        else parent[r2] = r1, height[r1]++;

        return 1;
    }
    return 0;
}

void reinit(){
    for(int i=1; i<=n; ++i)
        parent[i] = -1, height[i] = 0;
}

bool comp(vector<int>&x, vector<int>&y){
    return x[2] < y[2];
}

int kruskal(){
    reinit();
    sort(muchii.begin(), muchii.end(), comp);

    int sel = 0, ct = 0;
    for(int i=0; i < muchii.size() && sel < n-1; ++i){
        if(Union(muchii[i][0], muchii[i][1]))
            v.push_back(muchii[i]), ++sel, ct += muchii[i][2];
    }
    muchii = v;
    v.clear();
    return ct;
}

int main(){
    int x, y, z, k, m;
    fin>>n>>m;
    for(int i=0; i<m; ++i){
        fin>>x>>y>>z;
        muchii.push_back({x, y, z});
    }

    int ct;
    ct = kruskal();
    fout<<ct<<'\n';
    fin>>k;

    for(int i=0; i<k; ++i)
    {
        fin>>x>>y>>z;
        if(z < muchii.back()[2]){
            muchii.push_back({x, y, z});
            ct = kruskal();
        }
        fout<<ct<<'\n';
    }
}
