/*
 * Prim, O(mm)
 */

#include <bits/stdc++.h>

using namespace std;
ifstream fin("retea2.in");
ofstream fout("retea2.out");
int n, m, viz[4005];
double ct, minim[4005], d;

struct Pct{
    int x, y;
} v[4005];

double dist(Pct a, Pct b){
    return sqrt(1ll*(a.x - b.x)*(a.x - b.x) + 1ll*(a.y - b.y)*(a.y - b.y));
}

int main(){
    fin >> n >> m;
    for(int i=1; i<=n; i++){
        fin >> v[i].x >> v[i].y;
        viz[i] = 1;
    }
    for(int i=n+1; i<=n+m; i++){
        fin >> v[i].x >> v[i].y;
        minim[i] = 1e13;
        for(int j=1; j<=n; j++) {
            d = dist(v[i], v[j]);
            if (minim[i] > d) minim[i] = d;
        }
    }

    int sel = n, x;
    while(sel < n + m){
        sel++;
        double cmin = 1e13;
        // aleg nodul cu valoarea cea mai mica dintre cele nevizitate
        for(int i=n+1; i<=n+m; i++)
            if(!viz[i] && cmin > minim[i]) cmin = minim[i], x = i;
        ct += cmin;
        viz[x] = 1;
        // actualizez valorile minime
        for(int i=n+1; i<=n+m; i++)
            if(!viz[i] && minim[i] > dist(v[x], v[i])) minim[i] = dist(v[x], v[i]);
    }

    fout<<fixed<<setprecision(6)<<ct;

}