/*
 * Dijkstra, O((e+v)*log(v))
 */

#include<bits/stdc++.h> 
class Solution {
public:
    double maxProbability(int n, vector<vector<int>>& edges, vector<double>& succProb, int start, int end) {
        vector<vector<pair<int, double>>> list(n);
        for(int  i=0; i<edges.size(); i++)
            list[edges[i][0]].push_back({edges[i][1], succProb[i]}),
            list[edges[i][1]].push_back({edges[i][0], succProb[i]});
        
        priority_queue<pair<double, int>> q; // imi da nodul cu cea mai mare probabilitate
        q.push({1, start});
        
        vector<bool> viz(n);
        vector<double> prob(n);
        
        while(!q.empty()){
            // extrag nodul cu cea mai mare probabilitate
            auto x = q.top();
            q.pop();
            
            // daca nu a fost vizitat, il vizitez acum
            // si actualizez toate nodurile adiacente lui
            if(!viz[x.second]){
                viz[x.second] = 1;
            
                for(auto i: list[x.second]){
                    if(!viz[i.first] && prob[i.first] < x.first * i.second){
                        prob[i.first] = x.first * i.second;
                        q.push({prob[i.first], i.first});
                    }
                }
            }
        }
        
        return prob[end];
        
        }
};