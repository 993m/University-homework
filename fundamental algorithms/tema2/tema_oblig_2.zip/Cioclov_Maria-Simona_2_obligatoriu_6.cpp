/*
 * Dsf calculand sumele partiale, O(n+m) pe test
 */

#include <bits/stdc++.h>
using namespace std;
ifstream fin("easygraph.in");
ofstream fout("easygraph.out");

vector<vector<int>> lista;
vector<long long> suma;
vector<bool> viz;
vector<int> v;
long long maxim;

void dfs (int x){
    viz[x] = 1;
    suma[x] = v[x];
    for(auto y: lista[x]){
        if(!viz[y]) dfs(y); // dupa dfs(y) stiu care e suma[y] = suma maxima care se poate obtine incepand lantul cu nodul y
        suma[x] = max(suma[x], v[x] + suma[y]);
    }
    if(suma[x] > maxim) maxim = suma[x];
}

int main(){
    int t, n, m, x, y;
    fin>>t;
    while(t){
        fin>>n>>m;
        v = vector<int> (n+1);
        for(int i=1; i<=n; i++) fin>>v[i];
        lista = vector<vector<int>> (n+1);
        for(int i=1; i<=m; i++){
            fin>>x>>y;
            lista[x].push_back(y);
        }

        suma = vector<long long> (n+1);
        viz = vector<bool> (n+1);
        maxim = -1e7;

        for(int i=1; i<=n; i++)
            if(!viz[i]) dfs(i);

        fout<<maxim<<'\n';

        t--;
    }
}
