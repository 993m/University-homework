/*
 * Dijkstra, O((e+v)*log(v))
 * Pun in coada la inceput toate fortaretele
 */

#include <bits/stdc++.h>
using namespace std;
ifstream fin("catun.in");
ofstream fout("catun.out");
int n, m, k;

int main(){
    fin>>n>>m>>k;
    vector<vector<pair<int, int>>> lista(n);
    vector<int> fortarete;
    int f, x, y, z;
    for(int i=0; i<k; i++) fin>>f, fortarete.push_back(f-1);
    for(int i=0; i<m; i++){
        fin>>x>>y>>z;
        lista[x-1].push_back({y-1, -z});
        lista[y-1].push_back({x-1, -z});
    }

    vector<int> fortareata(n, -1); // cea mai apropiata fortareata de un nod
    vector<int> dist(n, -1e9); // cea mai buna distanta pana la un nod
    vector<int> viz(n); // daca nodul a fost vizitat

    // imi va da nodul la care ajung cel mai rapid
    priority_queue<pair<int, int>> q;
    // adaug fortaretele in coada cu distanta 0
    for(auto f: fortarete)
        q.push({0, f}), fortareata[f] = f, dist[f] = 0;

    while(!q.empty()){
        // extrag nodul la care ajung cel mai rapid
        auto x = q.top();
        q.pop();
        int nod = x.second;
        int d = x.first;

        // daca acesta nu a fost vizitat, il vizitez si actualizez distantele pentru nodurile adiacente lui
        //
        if(!viz[nod]){
            viz[nod] = 1;

            for(auto y: lista[nod]){
                if(!viz[y.first])
                    if(dist[y.first] < d + y.second){
                        dist[y.first] = d + y.second;
                        fortareata[y.first] = fortareata[nod];
                        q.push({dist[y.first], y.first});
                    }
                    else if(dist[y.first] == d + y.second)
                        // daca un nod se afla la aceeasi distanta fata de doua fortarete
                        // trebuie legat de fortareata cu indice mai mic
                        fortareata[y.first] = min(fortareata[nod], fortareata[y.first]);
            }
        }
    }

    for(auto i: fortarete) fortareata[i] = -1;
    for(auto i: fortareata) fout<<i+1<<" ";
}
