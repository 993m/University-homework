/*
 * O(mlogn)
 */

#include <bits/stdc++.h>

using namespace std;
ifstream fin("disjoint.in");
ofstream fout("disjoint.out");
int n, m, c, x, y, r1, r2, parent[100001], h[100001];

int root(int x){
    if(parent[x] == 0) return x;
    return root(parent[x]);
}

int main() {
    fin >> n >> m;

    for(int i=1; i<=m; i++){
        fin>>c>>x>>y;
        r1 = root(x);
        r2 = root(y);

        if(c==1){
            // subordonez arborele de inaltime mai mica celui de inaltime mai mare
            if(h[r1] < h[r2]) parent[r1] = r2;
            else if(h[r2] == h[r1]) parent[r1] = r2, h[r2] = h[r2] + 1;
            else parent[r2] = r1;
        }
        else{
            // daca nodurile au aceeasi radacina, inseamna ca se gasesc in acelasi set
            if(r1 == r2) fout<<"DA\n";
            else fout<<"NU\n";
        }
    }
    return 0;
}