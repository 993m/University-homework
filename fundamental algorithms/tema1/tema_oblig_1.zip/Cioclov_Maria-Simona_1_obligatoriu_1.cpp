/*

Am implementat bfs.
viz[i] = 0 -> nodul nu a fost vizitat
        viz[i] = 1 -> nodul face parte din primul grup
        viz[i] = 2 -> nodul face parte din al doilea grup
Nodurile adiacente vor fi marcate ca facand parte din grupuri diferitre.
Graful nu este bipatit daca doua noduri adiacente ajung sa apartina aceluiasi grup (viz[i] == viz[j])

O(n)

*/



class SolutionA {
public:
    int viz[2005];

    bool possibleBipartition(int n, vector<vector<int>>& dislikes) {
        vector<vector<int>> lista(n );

        for(auto i: dislikes)
            lista[i[0] - 1].push_back(i[1] - 1),
                    lista[i[1] - 1].push_back(i[0] - 1);

        int x;
        queue<int> q;
        for(int i=0; i<n; i++)
            if(!viz[i])
            {
                q.push(i);
                viz[i] = 1;
                while(!q.empty())
                {
                    x = q.front();
                    q.pop();
                    for(auto j: lista[x])
                        if(viz[j] == viz[x]) return 0;
                        else if(!viz[j]){
                            viz[x]==1 ? viz[j] = 2 : viz[j] = 1;
                            q.push(j);
                        }
                }
            }
        return 1;
    }
};





class SolutionB {
public:
    int viz[2005];

    vector<vector<int>> possibleBipartition(int n, vector<vector<int>>& dislikes) {
        vector<vector<int>> lista(n);
        vector<vector<int>> grupuri(2);
        vector<vector<int>> gol(2);

        for(auto i: dislikes)
            lista[i[0] - 1].push_back(i[1] - 1),
                    lista[i[1] - 1].push_back(i[0] - 1);


        int x, ok = 1;
        queue<int> q;
        for(int i=0; i<n && ok; i++)
            if(!viz[i])
            {
                q.push(i);
                viz[i] = 1;
                while(!q.empty() && ok)
                {
                    x = q.front();
                    q.pop();

                    grupuri[viz[x] - 1].push_back(x);

                    for(auto j: lista[x])
                        if(viz[j] == viz[x]) {ok = 0; break;}
                        else if(!viz[j]){
                            viz[x]==1 ? viz[j] = 2 : viz[j] = 1;
                            q.push(j);
                        }
                }
            }

        if(ok){
            for(auto i: grupuri[0]) cout<<i+1<<" ";
            cout<<endl;
            for(auto i: grupuri[1]) cout<<i+1<<" ";

            return grupuri;
        }
        else {
            cout<<"nu este bipartit";
            return gol;
        }
    }
};