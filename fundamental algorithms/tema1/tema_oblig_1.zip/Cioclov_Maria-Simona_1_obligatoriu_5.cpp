/*
 Parcurg graful cu bfs.
 Initial adaug in coada punctele de control.
 dist[i] != 0    =>  nodul i a fost vizitat
 dist[i]         =   (lungimea drumului parcurs pana la acel nod) + 1

 */

#include <iostream>
#include <vector>
#include <queue>
using namespace std;
int n, m, x, y;
vector<vector<int>> lista;
vector<int> dist;
queue<int> q;

int main() {
    cin >> n >> m;
    lista = vector<vector<int>>(n);
    dist = vector<int>(n);
    for (int i = 0; i < m; i++) {
        cin >> x >> y;
        lista[x-1].push_back(y-1);
        lista[y-1].push_back(x-1);
    }

    //ctrl+D dupa ce am terminat de introdus datele
    while(cin>>x){
        q.push(x-1);
        dist[x-1] = 1;
    }

    while(!q.empty()){
        x = q.front();
        q.pop();
        for(auto i: lista[x])
            if(!dist[i]){
                dist[i] = dist[x] + 1;
                q.push(i);
            }
    }

    for(auto i: dist)
        cout<<i - 1<<" ";

}