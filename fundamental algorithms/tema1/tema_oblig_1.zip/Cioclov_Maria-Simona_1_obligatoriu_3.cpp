/*

Am implementat sortarea topologica folosind dfs si o stiva.
Cursurile vor fi legate de muchii orientate pentru a reprezenta ordinea in care trebuie urmarite.
Parcurg graful cu dfs, iar cand un nod nu mai are noduri adiacente nevizitate (ceea ce inseamna ca nu mai sunt alte cursuri care depind de cursul curent), acesta este introdus in stiva.

O(n)

*/


class SolutionA {
public:
    int viz[2000], st[2000], ok=1;
    vector<vector<int>> lista;
    vector<int> s, gol;

    void dfs(int x){
        viz[x] = 1;
        for(auto i: lista[x]){
            if(!ok) return;

            if(!viz[i])
                dfs(i);
            else if(!st[i]) ok=0;
        }

        s.push_back(x);
        st[x] = 1;
    }

    vector<int> findOrder(int numCourses, vector<vector<int>>& prerequisites) {
        for(int i=0;i<numCourses;i++)
            lista.push_back(s);
        for(auto i: prerequisites)
            lista[i[0]].push_back(i[1]);
        for(int i=0;i<numCourses;i++)
            if(!viz[i]) dfs(i);
        if(ok) return s;
        else return gol;
    }
};






class SolutionB {
public:
    int viz[2000], st[2000], ok;
    vector<vector<int>> lista;
    vector<int> s, gol;

    void dfs(int x){
        viz[x] = 1;
        for(auto i: lista[x]){
            if(!ok) return;

            if(!viz[i])
                dfs(i);
            else if(!st[i]) s.push_back(i), ok=0;
        }

        s.push_back(x);
        st[x] = 1;
    }

    vector<int> findOrder(int numCourses, vector<vector<int>>& prerequisites) {
        for(int i=0;i<numCourses;i++)
            lista.push_back(s);
        for(auto i: prerequisites)
            lista[i[0]].push_back(i[1]);
        for(int i=0;i<numCourses;i++)
            if(!viz[i]) {
                ok = 1;
                dfs(i);
                if(!ok) return s;
                while(!s.empty()) s.pop_back();
            }

        return gol;
    }
};