/*
Pentru fiecare nod din vector:
verific daca urmatorul nod din parcurgere ii este adiacent.
	Daca da, atunci continui algoritmul de la nodul din urma.
	Daca nu, atunci verific daca toti copiii nodului curent au fost vizitati.
		Daca nu au fost, inseamna ca permutarea nu corespunde unui dfs.
		Daca au fost, inseamna ca parcurgerea incepand cu acel nod s-a terminat 
		 si trebuie sa ma intorc si sa reiau algoritmul de la nodul anterior.
		 

O(n^2)

*/



#include <iostream>
#include <vector>
using namespace std;
int n, m, v[100005], index = 1, viz[100005], fals;
vector<vector<int>> lista (1);
vector<int> vec (1);

void dfs(int x) {
    viz[v[x]] = 1;
    int ok = 1;
    while(ok){
        if(index == n || fals) return;
        ok = 0;
        for(auto i: lista[v[x]])
            if(i == v[index + 1]) {
                index++;
                dfs(index);
                ok = 1;
            }
    }
    
    for(auto i: lista[v[x]])
        if(!viz[i] && i != 0) fals = 1;
}

int main() {
    int x, y;
    cin>>n>>m;
    for(int i=1; i<=n; i++) cin>>v[i], lista.push_back(vec);
    for(int i=0; i<m; i++) {
        cin>>x>>y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }
    
    dfs(1);
    if(index == n) cout<<1;
    else cout<<0;
    return 0;
    
}