/*
 Am folosit algoritmul lui Tarjan.

 Parcurg graful cu DFS. Pentru fiecare nod memorez si actualizez pe parcurs:
    disc[i] = momentul in care a fost descoperit acel nod
    low[i] = nodul care care a fost descoperit cel mai devreme din subarborele care are ca radacina nodul i

 Daca low[y] > disc[x], inseamna ca [x, y] este o conexiune critica.

 O(n + m) - traversez o data graful, cu dfs

 */

class Solution {
public:
    vector<vector<int>> critical;
    int timer;

    void tarjan(int x, vector<vector<int>>& list, vector<int>& disc, vector<int>& low, vector<int>& parent){
        low[x] = timer;
        disc[x] = timer;
        timer++;

        for(auto i: list[x])
            if(disc[i] == -1){
                parent[i] = x;
                tarjan(i, list, disc, low, parent);
                if(low[x] > low[i]) low[x] = low[i];
                if(low[i] > disc[x]) critical.push_back({x, i});
            }

            else if(i != parent[x])
                if(low[x] > disc[i]) low[x] = disc[i];
    }

    vector<vector<int>> criticalConnections(int n, vector<vector<int>>& connections) {
        vector<vector<int>> list(n);
        vector<int> disc(n, -1);
        vector<int> low(n, -1);
        vector<int> parent(n, -1);
        for(auto i: connections)
            list[i[0]].push_back(i[1]),
            list[i[1]].push_back(i[0]);

        tarjan(0, list, disc, low, parent);


        return critical;
    }
};