/*
 * Parcurg graful de doua ori, prima data incepand cu nodul de start (x), iar a doua oara cu nodul final (y).
 * Pentru fiecare parcurgere pastrez si un vector de distante corespunzator.
 *
 * Daca distanta de la nodul initial (x) pana la un nod i, adunata cu distanta de la nodul final (y) pana la acel nod i
 * este egala cu distanta minima de la x la y, inseamna ca nodul i apartine unui drum minim de la x la y.
 *
 * Ca un nod i sa se gaseasca pe toate drumurile minime de la x la y este nevoie ca, pentru toate drumurile minime de la x la y,
 * nodul i sa fie singurul care se afla d fata de unul dintre capetele drumului.
 *
 * O(N + M)
 */

#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("graf.in");
ofstream fout("graf.out");
int n, m, x, y, d1[7505], d2[7505], nr[7505], nod[7505], k, v[7505];
vector<vector<int>> list;
queue<int> q;

int main(){
    int a, b, s, ok;
    fin>>n>>m>>x>>y;
    list = vector<vector<int>>(n + 1);
    for(int i=0; i<m; i++){
        fin>>a>>b;
        list[a].push_back(b);
        list[b].push_back(a);
    }

    d1[x] = d2[y] = 1;

    q.push(x);
    while(!q.empty()){
        a = q.front();
        q.pop();
        for(auto i: list[a])
            if(!d1[i]){
                d1[i] = d1[a] + 1, q.push(i);
            }
    }

    q.push(y);
    while(!q.empty()){
        a = q.front();
        q.pop();
        for(auto i: list[a])
            if(!d2[i]){
                d2[i] = d2[a] + 1, q.push(i);
            }
    }


    for(int i=1; i<=n; i++)
        if(d1[i] + d2[i] == d1[y] + 1)
            nr[d1[i]]++, nod[d1[i]] = i;

    for(int i=1; i<=d1[y]; i++)
        if(nr[i] == 1) v[nod[i]] = 1, k++;

    fout<<k<<endl;
    for(int i=1; i<=n; i++)
        if(v[i]) fout<<i<<" ";

    return 0;
}