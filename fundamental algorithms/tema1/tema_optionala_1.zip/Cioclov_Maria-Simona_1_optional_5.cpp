/*
 * Cu dfs am aflat care sunt componentele conexe si cate elemente are fiecare.
 *
 * O(n*m) (n*m este numarul de noduri din graf)
 */

class Solution {
public:
    int cnt[2000], k, n, m, dl[4] = {-1,0,1,0}, dc[4] = {0,1,0,-1}, max, x, y;
    pair<int, int> p;

    bool valid(int x, int y){
        if(x<0 || y<0 || x>=n || y>=m) return 0;
        return 1;
    }

    void dfs(vector<vector<int>>& grid, vector<vector<int>>& cc, pair<int, int> p){
        cnt[k]++;
        for(int i=0; i<4; i++){
            x = dl[i] + p.first;
            y = dc[i] + p.second;

            if(valid(x, y) && !cc[x][y] && grid[x][y])
                cc[x][y] = k, dfs(grid, cc, {x, y});
        }

    }

    int maxAreaOfIsland(vector<vector<int>>& grid) {
        n = grid.size();
        m = grid[0].size();
        vector<vector<int>> cc (n, vector<int>(m, 0));
        for(int i=0; i<n; i++)
            for(int j=0; j<m; j++)
                if(grid[i][j] && !cc[i][j]){
                    k++;
                    cc[i][j] = k;
                    dfs(grid, cc, {i,j});
                }

        for(int i=1; i<=k; i++)
            if(cnt[i] > max)  max = cnt[i];

        return max;

    }
};