/*
 * Pornesc un bfs din punctul de plecare si adaug nodurile la inceputul sau la sfarsitul unui deque astfel incat
 * sa fie vizitate intai nodurile vecine la care ajung cu cost 0 si abia apoi pe cele la care ajung cu cost 1.
 * Adaug un nod in deque doar daca acesta nu a fost vizitat sau daca ajung la acesta cu un pret mai mic decat cel cu care ajungeam anterior.
 *
 * O(V*E)
 */

#include <fstream>
#include <deque>
using namespace std;
ifstream fin("padure.in");
ofstream fout("padure.out");
int m, n, pl, pc, cl, cc, x, y, a[1005][1005], p[1005][1005], dl[4] = {-1, 0, 1, 0}, dc[4] = {0, 1, 0, -1};
deque<pair<int, int>> d;
pair<int, int> pct;

bool valid(int x, int y){
    if(x < 1 || x > n || y < 1 || y > m) return 0;
    return 1;
}

int main(){
    fin>>n>>m>>pl>>pc>>cl>>cc;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m; j++) fin>>a[i][j];

    d.push_back({pl, pc});
    p[pl][pc] = 1;
    while(!d.empty()){
        pct = d.front();
        d.pop_front();
        for(int i=0; i<4; i++){
            x = pct.first + dl[i];
            y = pct.second + dc[i];
            if(valid(x, y))
                if(a[pct.first][pct.second] == a[x][y]) {
                    if (p[x][y] > p[pct.first][pct.second] || !p[x][y])
                        p[x][y] = p[pct.first][pct.second], d.push_front({x, y});
                }
                else  if(p[x][y] > p[pct.first][pct.second] + 1 || !p[x][y])
                    p[x][y] = p[pct.first][pct.second] + 1, d.push_back({x, y});
        }
    }

    fout<<p[cl][cc] - 1;

    return 0;
}